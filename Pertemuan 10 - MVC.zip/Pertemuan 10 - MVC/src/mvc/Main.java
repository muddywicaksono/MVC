package mvc;

public class Main {

    public static void main(String[] args) {
        // memanggil class MhsMVC agar berjalan
        MhsMVC mvc = new MhsMVC();
    }

}
